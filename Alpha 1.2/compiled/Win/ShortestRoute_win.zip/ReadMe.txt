INSTRUCTIONS
==================
1. Run ShortestRoute_win32.exe
2. Enter starting classroom (see classroom list for available classrooms)
3. Enter end classroom (cannot be the same as the starting classroom)
4. Once you're done simply exit by clicking the red X on the top right.


Acknowledgements
==================
Geekly yours: http://geekly-yours.blogspot.com.au/2014/03/dijkstra-algorithm-python-example-source-code-shortest-path.html


Classroom List
==================
A1, A2, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A19, A20, A22, A23, A24, A25, A26, A27, A28, A29, A30, 
A31, A32, A33, A34, A35, A36, A37, A38, A39, A40, A41, A42, A43, A44, A45, A46, A47, A48, A49, E1, E6, D1, B1, B2



Written by Jett Jackson, classrooms measured by serina-winter and Bhavna Venkat.






License
==================

Copyright (c) 2015 Jett Jackson

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.